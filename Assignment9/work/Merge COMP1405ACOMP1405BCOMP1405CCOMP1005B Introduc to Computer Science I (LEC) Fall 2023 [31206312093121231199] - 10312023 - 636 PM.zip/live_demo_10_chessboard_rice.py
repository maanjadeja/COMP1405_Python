def main():

	# as with the waterlily sim, only two variables are needed
	#  - rice, which is a running total for the "cost" (in rice) for the chessboard
	#  - cost, which is the cost to be paid for the next square
	rice = 0
	cost = 1
	
	# since the number of squares on the chessboard is fixed, this is obviously a
	# counter-controlled (and not event-controlled) loop, but since we don't need to
	# actually access the counter value, we can use an underscore instead of a variable
	for _ in range(64):
	
		# as we consider each square, the total cost increases by the cost paid for 
		# the next square, and then the cost for the square after that is double
		rice += cost
		cost *= 2

	# after the loop has terminated, the rice variable is the user's "answer"	
	print(f"The final cost (in grains of rice) for the chessboard is {rice}.")
	

main()