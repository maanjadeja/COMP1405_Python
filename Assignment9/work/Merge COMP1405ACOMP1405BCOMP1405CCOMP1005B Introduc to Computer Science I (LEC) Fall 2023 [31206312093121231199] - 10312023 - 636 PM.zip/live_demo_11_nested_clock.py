# the time library is imported to gain access to the sleep function
# the sleep function causes your program to wait for the number of 
# seconds specified in your argument
import time

# don't forget that the range function has default values for the
# stop and step parameters (but no default for the stop parameter)
# range(start, stop, step)  # all three arguments provided
# range(start, stop)        # start and stop provided, step defaults to 1
# range(stop)               # stop provided, start defaults to 0, step defaults to 1

def main():

	# the clock is going to start at 1:00 AM on day 000
	am_or_pm_label = "AM"

	# the "outermost" loop counts the days
	for day in range(1000):

		# the underscore here just indicates to python that I do not
		# intend to use this particular variable for anything
		for _ in range(2):

			# outer loop, governing the hour
			# minimum hour value is 1, so "start" is 1
			# maximum hour value is 12, so "stop" needs to be 13

			# for h in range(1, 13, 1):
			for h in range(1, 13):

				# inner loop, governing the minute
				# minimum minute value is 0, so "start" is 0 (which is the default)
				# maximum minute value is 59, so "stop" needs to be 60

				# for m in range(0, 60, 1):
				for m in range(60):

					# the "innermost" loop counts the seconds
					for s in range(60):
					
						# I update the clock display with every passing second
						print(f"{h:02}:{m:02} {am_or_pm_label}")

						# if you wanted your clock to actually work (sort of) 
						# you could have your program wait 1 second here...
						# ...but this won't work well because your computer
						# will be doing other stuff as well, meaning that you
						# will spend more than 1 second total on each iteration
						# time.sleep(1)

				# the change from AM to PM occurs when hour 11 has finished (i.e., 11:59)					
				if h == 11:
					if am_or_pm_label == "AM":
						am_or_pm_label = "PM"
					else:
						am_or_pm_label = "AM"

				# adding a pause here makes the whole process a bit easier to follow
				# when trying to monitor the output on the terminal
				time.sleep(1)
	

main()