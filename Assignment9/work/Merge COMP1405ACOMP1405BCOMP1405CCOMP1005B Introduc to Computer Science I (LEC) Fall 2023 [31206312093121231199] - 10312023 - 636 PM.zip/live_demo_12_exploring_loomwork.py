from comp1405_f23_special_library_loomwork_simplified import *
from random import choice

# # ------------------------------------------------------------

# first up we have a single counter-controlled loop with a range
# stop value of 90 (which is the width of the final result) and
# since the body of the loop is just adding beads until we end
# the thread, we see the same column repeated 90 times
#
# n.b., the height of 13 is only used to open the window and not
# to actually construct each column - a dead giveaway that this
# can be improved

# wide = 90
# high = 13
# open_window(wide, high)
# for _ in range(wide):
	# add_bead("white")
	# add_bead("white")
	# add_bead("white")
	# add_bead("storm")
	# add_bead("storm")
	# add_bead("white")
	# add_bead("white")
	# add_bead("white")
	# add_bead("storm")
	# add_bead("storm")
	# add_bead("white")
	# add_bead("white")
	# add_bead("white")
	# next_thread()
# keep_window()

# # ------------------------------------------------------------

# our first improvement on the horizontal bands, having noticed
# that consecutive calls to add_bead with the same colour can be
# group into their own counter-controlled loop structures

# wide = 90
# high = 13
# open_window(wide, high)
# for _ in range(wide):
	# for _ in range(3):
		# add_bead("white")
	# for _ in range(2):
		# add_bead("storm")
	# for _ in range(3):
		# add_bead("white")
	# for _ in range(2):
		# add_bead("storm")
	# for _ in range(3):
		# add_bead("white")
	# next_thread()
# keep_window()

# # ------------------------------------------------------------

# an improvement attempt that doesn't quite work... it repeats
# the higher-level "white-band-then-storm-band" pattern	but the 
# target pattern needs to end on white...

# wide = 90
# high = 13
# open_window(wide, high)
# for _ in range(wide):
	# for _ in range(3):
		# for _ in range(3):
			# add_bead("white")
			
		# for _ in range(2):
			# add_bead("storm")
	# next_thread()
# keep_window()

# # ------------------------------------------------------------

# ... which is actually relatively easy to do with a well placed
# break statement (also demonstrated that the break instruction
# isn't just for event-controlled loops

# wide = 90
# high = 13
# open_window(wide, high)
# for _ in range(wide):
	# for i in range(3):
		# for _ in range(3):
			# add_bead("white")
		# if i == 2:            # after the third band of white...
			# break             # ...stop working on the current vertical thread
		# for _ in range(2):
			# add_bead("storm")
	# next_thread()
# keep_window()

# # ------------------------------------------------------------

# and now for something completely different - vertical bands 
# (instead of horizontal) achieved by using modulo to determine
# if the column index i is an odd number or an even number

# wide = 90
# high = 13
# open_window(wide, high)
# for i in range(wide):
	# for _ in range(13):
		# if i % 2 == 0:
			# add_bead("white")
		# else:
			# add_bead("storm")
	# next_thread()
# keep_window()

# # ------------------------------------------------------------

# this technique even works when applying modulo with another
# value (this time 5) to get a repeating pattern of 5 different
# vertical bands

# wide = 90
# high = 13
# open_window(wide, high)
# for i in range(wide):
	# for _ in range(13):
		# if i % 5 == 0:
			# add_bead("white")
		# elif i % 5 == 1:
			# add_bead("storm")
		# elif i % 5 == 2:
			# add_bead("wine")
		# elif i % 5 == 3:
			# add_bead("dusk")
		# else:
			# add_bead("silver")
	# next_thread()
# keep_window()

# # ------------------------------------------------------------

# having noticed in the previous example that i % 5 is a value 
# in the range from 0 to 4 inclusive, this is a good opportunity
# to plug the linear collection in Python (i.e., the list) and 
# see how the colours can be contained in a structure outside of
# the loop, and then just referenced...

# wide = 90
# high = 13
# selected_colours = ["white", "storm", "wine", "dusk", "silver"]
# open_window(wide, high)
# for i in range(wide):
	# for _ in range(13):
		# if i % 5 == 0:
			# add_bead(selected_colours[0])
		# elif i % 5 == 1:
			# add_bead(selected_colours[1])
		# elif i % 5 == 2:
			# add_bead(selected_colours[2])
		# elif i % 5 == 3:
			# add_bead(selected_colours[3])
		# else:
			# add_bead(selected_colours[4])
	# next_thread()
# keep_window()

# # ------------------------------------------------------------

# ...and the subsequent realization that i % 5 == something test
# always leads to the use of selected_colours[same something], 
# provides another opportunity to improve the structure

# wide = 90
# high = 13
# selected_colours = ["white", "storm", "wine", "dusk", "silver"]
# open_window(wide, high)
# for i in range(wide):
	# for _ in range(13):
		# add_bead(selected_colours[i % 5])
	# next_thread()
# keep_window()




# # ------------------------------------------------------------

# in an effort to approach the same pattern in a different way
# (this time without modulo) first consider an abstraction of
# the "Twenty Four Nation" belt, which features a human glyph
# that is 24 weft threads wide, repeated until a width of 552
# has been reached...

# wide = 552
# ...
# for i in range(24):
	# create_a_single_figure(...)

# # ------------------------------------------------------------
	
# ...viewing our problem in the same way, we attempt to identify
# the so-called "pattern core" (i.e., sequence of weft threads
# that is being repeated until the desired with is reached)...
# in this case, the pattern core is the five consecutive threads
# of white->storm->wine->dusk->silver, and this core is repeated
# 18 times to reach the desired width of 90

# note the use of divide-and-conquer here, assuming we already
# have a "create_the_thread_of..." functions...

# wide = 90
# high = 13
# open_window(wide, high)
# for _ in range(18):	# i.e., width 90 divided by core size 5
	# create_the_thread_of_white(...)
	# create_the_thread_of_storm(...)
	# create_the_thread_of_wine(...)
	# create_the_thread_of_dusk(...)
	# create_the_thread_of_silver(...)
	# next_thread()
# keep_window()

# # ------------------------------------------------------------

# ...which would themselves be implemented like this:

# for _ in range(13):
	# add_bead(...)
	
# # ------------------------------------------------------------

# ...and using our list of colours from before (and making the
# colour an argument of "create_the_thread_of") gives us this 
# design

# wide = 90
# high = 13
# selected_colours = ["white", "storm", "wine", "dusk", "silver"]
# open_window(wide, high)
# for _ in range(18):
	# for colour in selected_colours:
		# create_the_thread_of(colour)
		# next_thread()
# keep_window()

# # ------------------------------------------------------------

# wide = 90
# high = 13
# selected_colours = ["white", "storm", "wine", "dusk", "silver"]
# open_window(wide, high)
# for _ in range(18):
	# for current_colour in selected_colours:
		# for _ in range(13):
			# add_bead(current_colour)
		# next_thread()
# keep_window()

# # ------------------------------------------------------------

# this is a different exercise - a "code reading"... what would 
# this program do if the index to selected_colours (inside the
# body of the innermost loop) was changed to i? j? k? m?

# wide = 20
# high = 10
# open_window(wide, high)
# selected_colours = ["white", "storm", "wine", "dusk", "silver"]
# for i in range(4):
	# for j in range(5):
		# for k in range(5):
			# for m in range(2):
				# add_bead(selected_colours[?]) 	# try i/j/k/m
		# next_thread()
# keep_window()

# # ------------------------------------------------------------

# what about this one? how does this work? note specifically how
# we have some variables x and y that are being modified from 
# inside some of these nested loops - how do these values change
# what is happening with the pattern?

wide = 88
high = 9
open_window(wide, high)

x = 0
y = 1

for _ in range(11):
	
	for _ in range(2):
	
		for _ in range(4):
		
			beads_in_the_middle = (2 * x) + 1

			beads_above_and_below = (high - beads_in_the_middle) // 2

			for k in range(beads_above_and_below): add_bead("storm")
			for k in range(beads_in_the_middle): add_bead("white")
			for k in range(beads_above_and_below): add_bead("storm")
			
			next_thread()
			
			x += y
			
		y *= -1
	
keep_window()